package testesFront;

import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import testesBack.AmbientedeTeste;

public class TestDriver extends AmbientedeTeste {

	protected WebDriver driver;
	
	@Before
	public void before() {
		System.setProperty("webdriver.chrome.driver", "C:/WebDriver/bin/chromedriver.exe");
		driver = new ChromeDriver();
	}
	@After
	public void after() {
		driver.close();
		driver.quit();
	}
	
	protected WebDriver getDriver() {
		return driver;
	}
}
