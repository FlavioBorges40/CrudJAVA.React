package testesFront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class NotificationPage extends BasePage {
	private WebDriver driver;
	
	public NotificationPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void criarNotificacao(String nome, String mensagem) {
		acessar(driver, "/notifications");
		input(driver,"nome").sendKeys(nome);
		input(driver,"mensagem").sendKeys(mensagem);
		button(driver,"criar").click();
	}
	
	public boolean verificarEstado(String resposta) {
		WebDriverWait esperar = new WebDriverWait(driver, 10);
		return esperar.until(ExpectedConditions.textToBePresentInElement(h3(driver,"resposta"), resposta));
	}
	
	public boolean verificarNotificacao(String nome) {
		try {
			elementFromTabela(driver,nome);
		}
		catch(Exception e) {
			return false;
		}
		return true;
	}
	
	public String verificarAlerta() {
		String text = driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		return text;
	}
	
	public void deletarNotificacao(String nome) {
		acessar(driver, "/notifications");
		buttonOperation(driver,nome,"deletar").click();
	}
	
	public void editarNotificacao(String nomeatual, String novonome, String novamensagem) {
		acessar(driver, "/notifications");
		buttonOperation(driver,nomeatual,"editar").click();
		input(driver,"nome").sendKeys(novonome);
		input(driver,"mensagem").sendKeys(novamensagem);
		button(driver,"salvar").click();
	}
	
	public void buscarNotificacao(String nome) {
		acessar(driver, "/notifications");
		input(driver,"nome").sendKeys(nome);
		button(driver,"buscar").click();
	}
	
	public void testarNotificacao(String nome) {
		acessar(driver, "/notifications");
		buttonOperation(driver,nome,"testar").click();
	}
}
