package testesFront;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class TestarNotificacaoFrontTest extends TestDriver {
	private NotificationPage notificacao;
	
	@Before
	public void gerarAmbiente() {
		notificacao = new NotificationPage(getDriver());
		criarNotificacao();
	}
	@After
	public void limparAmbiente() {
		apagarNotificacaoNome(getNotificacao());
	}
	
	@Test
	public void sucessoTestarNotificacao() {
		notificacao.testarNotificacao(getNotificacao().getName());
		Assert.assertEquals(notificacao.verificarAlerta(),getNotificacao().getMsg());
	}
}
