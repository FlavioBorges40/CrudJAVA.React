package testesFront;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CadastrarFrontTest extends TestDriver {
	private LoginPage cadastro;
	
	@Before
	public void gerarAmbiente() {
		cadastro = new LoginPage(getDriver());
		criarUsuarioValido();
	}
	
	@After
	public void limparAmbiente() {
		apagarUsuarioNovo();
		apagarUsuarioValido();
		deslogarUsuarioValido();
	}
	
	@Test
	public void sucessoCadastroUsuario() {
		cadastro.cadastrarUsuario(getUsuarioNovo().getUsername(),getUsuarioNovo().getPassword());
		Assert.assertTrue(cadastro.verificarEstado("Usuario cadastrado com sucesso."));
	}
	
	@Test
	public void falhaUsuarioJaExiste() {
		cadastro.cadastrarUsuario(getUsuarioValido().getUsername(),getUsuarioValido().getPassword());
		Assert.assertTrue(cadastro.verificarEstado("Nome de usuario ja existe, escolha outro."));
	}
	
	@Test
	public void falhaSenhaPequena() {
		cadastro.cadastrarUsuario(getUsuarioNovo().getUsername(),"1234");
		Assert.assertTrue(cadastro.verificarEstado("A senha deve ter mais de 8 caracteres."));
	}
}
