package testesFront;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CriarNotificacaoFrontTest extends TestDriver {
	private NotificationPage notificacao;
	
	@Before
	public void gerarAmbiente() {
		notificacao = new NotificationPage(getDriver());
		
	}
	@After
	public void limparAmbiente() {
		apagarNotificacaoNome(getNovaNotificacao());
	}
	
	@Test
	public void sucessoAdicionarNotificacao() {
		notificacao.criarNotificacao(getNovaNotificacao().getName(), getNovaNotificacao().getMsg());
		Assert.assertTrue(notificacao.verificarEstado("Criada com sucesso."));
	}
}
