package testesFront;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class AlterarNotificacaoFrontTest extends TestDriver {
	private NotificationPage notificacao;
	
	@Before
	public void gerarAmbiente() {
		notificacao = new NotificationPage(getDriver());
		criarNotificacao();
	}
	@After
	public void limparAmbiente() {
		apagarNotificacaoNome(getNotificacaoAlterada());
		apagarNotificacaoNome(getNotificacao());
	}
	
	@Test
	public void sucessoEditarNotificacao() {
		notificacao.editarNotificacao(getNotificacao().getName(), getNotificacaoAlterada().getName(), getNotificacaoAlterada().getMsg());
		Assert.assertTrue(notificacao.verificarEstado("Alterada com sucesso."));
	}
	
	@Test
	public void falhaCampoVazio() {
		notificacao.editarNotificacao(getNotificacao().getName(), "", "");
		Assert.assertTrue(notificacao.verificarEstado("Erro, algum campo est� vazio!"));
	}
}
