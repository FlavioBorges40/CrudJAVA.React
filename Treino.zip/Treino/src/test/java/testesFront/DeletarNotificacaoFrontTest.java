package testesFront;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class DeletarNotificacaoFrontTest extends TestDriver {
	private NotificationPage notificacao;
	
	@Before
	public void gerarAmbiente() {
		notificacao = new NotificationPage(getDriver());
		criarNotificacao();
	}
	@After
	public void limparAmbiente() {
	}
	
	@Test
	public void deletarNotificacao() {
		notificacao.deletarNotificacao(getNotificacao().getName());
		Assert.assertTrue(notificacao.verificarEstado("A notificacao foi apagada com sucesso."));
	}
}
