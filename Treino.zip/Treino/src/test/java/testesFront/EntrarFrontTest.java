package testesFront;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class EntrarFrontTest extends TestDriver{
	private LoginPage login;
	
	@Before
	public void gerarAmbiente() {
		login = new LoginPage(getDriver());
		criarUsuarioValido();
	}
	@After
	public void limparAmbiente() {
		apagarUsuarioValido();
		deslogarUsuarioValido();
	}
	
	@Test
	public void sucessoLogin() {
		login.efetuarLogin(getUsuarioValido().getUsername(),getUsuarioValido().getPassword());
		Assert.assertTrue(login.verificarEstado("Logado com sucesso."));
	}
	
	@Test
	public void falhaSenhaIncorreta() {
		login.efetuarLogin(getUsuarioValido().getUsername(),"senhaerrada123");
		Assert.assertTrue(login.verificarEstado("Senha incorreta."));
	}
	
	@Test
	public void falhaUsuarioInexistente() {
		login.efetuarLogin(getUsuarioInexistente().getUsername(),getUsuarioInexistente().getPassword());
		Assert.assertTrue(login.verificarEstado("Usuario nao existe."));
	}
}