package testesFront;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class BasePage {
	
	public void acessar(WebDriver driver, String slug) {
		driver.get("http://localhost:3000" + slug);
	}
	
	public WebElement button(WebDriver driver, String name) {
		return driver.findElement(By.xpath("//button[@id='"+ name +"']"));
	}
	
	public WebElement input(WebDriver driver, String name) {
		return driver.findElement(By.xpath("//input[@id='"+ name +"']"));
	}
	
	public WebElement h3(WebDriver driver, String name) {
		return driver.findElement(By.xpath("//h3[@id='"+ name +"']"));
	}
	
	public WebElement buttonClass(WebDriver driver, String name, String id) {
		return driver.findElement(By.xpath("//button[@id='"+ id +"' and @class='"+ name +"']"));
	}
	
	public WebElement buttonOperation(WebDriver driver, String nome, String op) {
//		String id;
//		id = driver.findElement(By.xpath("//td[contains(text(),'" + nome +"')]")).getAttribute("id");
//	    return driver.findElement(By.xpath("//button[@id='"+id+"' and @name='"+op+"']"));
		return driver.findElement(By.xpath("//td[contains(text(),'" + nome +"')]")).findElement(By.xpath("//button[@name='"+op+"']"));
	}
	
	public WebElement elementFromTabela(WebDriver driver, String nome) {
		return driver.findElement(By.xpath("//td[contains(text(),'" + nome +"')]"));
	}
}
