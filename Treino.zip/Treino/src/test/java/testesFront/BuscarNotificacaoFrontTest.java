package testesFront;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class BuscarNotificacaoFrontTest extends TestDriver {
	private NotificationPage notificacao;
	
	@Before
	public void gerarAmbiente() {
		notificacao = new NotificationPage(getDriver());
		criarNotificacao();
	}
	@After
	public void limparAmbiente() {
		apagarNotificacaoNome(getNotificacao());
	}
	
	@Test
	public void sucessoBuscarNotificacao() {
		notificacao.buscarNotificacao(getNotificacao().getName());
		Assert.assertTrue(notificacao.verificarNotificacao(getNotificacao().getName()));
	}
	
	@Test
	public void falhaNotificacaoNaoEncontrada() {
		notificacao.buscarNotificacao("N�o existe");
		Assert.assertTrue(notificacao.verificarEstado("Nao encontrada nenhuma notificacao."));
	}
}

