package testesFront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage extends BasePage {
	private WebDriver driver;
	
	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void efetuarLogin(String username, String password) {
		acessar(driver, "/login");
		input(driver, "user-login").sendKeys(username);
		input(driver, "user-password").sendKeys(password);
		button(driver, "entrar").click();
	}
	
	public boolean verificarEstado(String resposta) {
		WebDriverWait esperar = new WebDriverWait(driver, 10);
		return esperar.until(ExpectedConditions.textToBePresentInElement(h3(driver,"resposta"), resposta));
	}

	public void cadastrarUsuario(String username, String password) {
		acessar(driver, "/login");
		input(driver, "user-login").sendKeys(username);
		input(driver, "user-password").sendKeys(password);
		button(driver, "cadastrar").click();
	}
}
