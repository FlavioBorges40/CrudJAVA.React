package testes;

import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.google.gson.Gson;

import entity.Notificacao;

public class CriarNotificacaoTest extends AmbientedeTeste{
	
	@Before
	public void gerarAmbiente() throws Exception{
	}
	@After
	public void limparAmbiente() throws Exception{
	}
	
	@Test
	public void sucessoCriarNotificacao() throws Exception{
		// Arrange
		Gson gson = new Gson();
		Notificacao notificacao = getNovaNotificacao();
				
		// Act
		String request = gson.toJson(notificacao);
				
		String responseJson =
				Request.Post(getUriNot() + "/criar")
					.bodyString(request, ContentType.APPLICATION_JSON)
					.execute()
					.returnContent().toString();
		
		buscarNotificacaoApagar(notificacao);
		
		// Assert
		Assert.assertEquals("Criada com sucesso.", responseJson);
	}
}
