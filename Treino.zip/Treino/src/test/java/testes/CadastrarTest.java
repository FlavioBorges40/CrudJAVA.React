package testes;

import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.google.gson.Gson;

import entity.Usuario;

public class CadastrarTest extends AmbientedeTeste{
	
	@Before
	public void gerarAmbiente() throws Exception {
		criarUsuarioValido();
	}
	
	@After
	public void limparAmbiente() throws Exception {
		apagarUsuarioNovo();
		apagarUsuarioValido();
		deslogarUsuarioValido();
	}
	
	@Test
	public void sucessoCadastroUsuario() throws Exception {
		// Arrange
		Gson gson = new Gson();
		Usuario user = getUsuarioNovo();
		
		// Act
		String request = gson.toJson(user);
		
		String response =
				Request.Post(getUriAuth() + "/cadastrar")
					.bodyString(request, ContentType.APPLICATION_JSON)
					.execute()
					.returnContent().toString();
		
		// Assert
		Assert.assertEquals("Usuario cadastrado com sucesso.", response);
	}
	
	@Test
	public void falhaUsuarioJaExiste() throws Exception {
		// Arrange
		Gson gson = new Gson();
		Usuario user = getUsuarioValido();
				
		// Act
		String request = gson.toJson(user);
				
		String response =
				Request.Post(getUriAuth() + "/cadastrar")
					.bodyString(request, ContentType.APPLICATION_JSON)
					.execute()
					.returnContent().toString();
				
		// Assert
		Assert.assertEquals("Nome de usuario ja existe, escolha outro.", response);
	}
}
