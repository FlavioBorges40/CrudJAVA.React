package testes;

import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.google.gson.Gson;

import entity.Token;

public class SairTest extends AmbientedeTeste{
	
	@Before
	public void gerarAmbiente() throws Exception{
		requestAdicionarTokens();
	}
	
	@After
	public void limparAmbiente() throws Exception{
		requestApagarTokens();
	}
	
	@Test
	public void sucessoSair() throws Exception {
		// Arrange
		Gson gson = new Gson();
		// Act
		String request = gson.toJson(getTokenValido());
		
		String response =
				Request.Post("http://localhost:8080/Treino/dog/auth/sair")
					.bodyString(request, ContentType.APPLICATION_JSON)
					.execute()
					.returnContent().toString();
		
		// Assert
		Assert.assertEquals("Deslogado com sucesso.", response);
	}
	
	@Test
	public void falhaSairExpirado() throws Exception {
		// Arrange
		Gson gson = new Gson();
		
		// Act
		String request = gson.toJson(getTokenInvalido());
		
		String response =
				Request.Post("http://localhost:8080/Treino/dog/auth/sair")
					.bodyString(request, ContentType.APPLICATION_JSON)
					.execute()
					.returnContent().toString();
		
		// Assert
		Assert.assertEquals("Usuario ja desconectado.", response);
	}
	
	@Test
	public void falhaSairJaDeslogado() throws Exception {
		// Arrange
		Gson gson = new Gson();
		Token token = new Token("tokenquejafoiapagadoanteriormenteouinexistentenobd","Teste2","2020-03-07 15:30:00");
		
		// Act
		String request = gson.toJson(token);
		
		String response =
				Request.Post("http://localhost:8080/Treino/dog/auth/sair")
					.bodyString(request, ContentType.APPLICATION_JSON)
					.execute()
					.returnContent().toString();
		
		// Assert
		Assert.assertEquals("Usuario ja desconectado.", response);
		
	}
	
}
