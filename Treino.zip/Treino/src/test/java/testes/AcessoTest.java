package testes;

import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.google.gson.Gson;

import entity.TokenPermissaoTO;

public class AcessoTest extends AmbientedeTeste {

	@Before
	public void gerarAmbiente() throws Exception{
		criarUsuarioValido();
		requestAdicionarTokens();
		adicionarPermissaoValida();
	}
	
	@After
	public void limparAmbiente() throws Exception{
		apagarUsuarioValido();
		requestApagarTokens();
		apagarPermissaoValida();
	}
	
	@Test
	public void sucessoAcessarPaginaRestrita() throws Exception {
		// Arrange
		Gson gson = new Gson();
		TokenPermissaoTO perm = new TokenPermissaoTO(getTokenValido().getToken(),getPermissaoValida().getUri());
				
		// Act
		String request = gson.toJson(perm);
				
		String response = Request.Post(getUriAuth() + "/permissao")
							.bodyString(request, ContentType.APPLICATION_JSON)
							.execute()
							.returnContent().toString();
				
		// Assert
		Assert.assertEquals("Acesso liberado.", response);
	}
	
	@Test
	public void falhaAcessarPaginaRestrita() throws Exception {
		// Arrange
		Gson gson = new Gson();
		TokenPermissaoTO perm = new TokenPermissaoTO(getTokenValido().getToken(),"/secreto");
		
		// Act
		String request = gson.toJson(perm);
		
		String response = Request.Post(getUriAuth() + "/permissao")
							.bodyString(request, ContentType.APPLICATION_JSON)
							.execute()
							.returnContent().toString();
		// Assert
		Assert.assertEquals("Acesso negado.", response);
	}
}
