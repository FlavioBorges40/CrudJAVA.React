package testes;

import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.google.gson.Gson;

import entity.Usuario;

public class EntrarTest extends AmbientedeTeste {
	
	@Before
	public void gerarAmbiente() throws Exception {
		criarUsuarioValido();
	}
	
	@After
	public void limparAmbiente() throws Exception {
		apagarUsuarioValido();
		deslogarUsuarioValido();
	}
	
	@Test
	public void sucessoSenhaValida() throws Exception {
		// Arrange
		Gson gson = new Gson();
		Usuario user = getUsuarioValido();
		
		// Act
		String request = gson.toJson(user);
		
		String response =
				Request.Post(getUriAuth() + "/entrar")
					.bodyString(request, ContentType.APPLICATION_JSON)
					.execute()
					.returnContent().toString();
		
		// Assert
		Assert.assertEquals("Logado com sucesso.", response);
	}
	
	
	@Test
	public void falhaSenhaInvalida() throws Exception {
		// Arrange
		Gson gson = new Gson();
		Usuario user = new Usuario(getUsuarioValido().getUsername(),"aleatoriamente");
		
		// Act
		String request = gson.toJson(user);
		
		String response =
				Request.Post(getUriAuth() + "/entrar")
					.bodyString(request, ContentType.APPLICATION_JSON)
					.execute()
					.returnContent().toString();
		
		// Assert
		Assert.assertEquals("Senha incorreta.", response);
	}

	@Test
	public void falhaUsuarioNaoEncontrado() throws Exception {
		// Arrange
		Gson gson = new Gson();
		Usuario user = new Usuario("Inexistente","12");
		
		// Act
		String request = gson.toJson(user);
		
		String response =
				Request.Post(getUriAuth() + "/entrar")
					.bodyString(request, ContentType.APPLICATION_JSON)
					.execute()
					.returnContent().toString();
		
		// Assert
		Assert.assertEquals("Usuario nao existe.", response);
		
	}
}
