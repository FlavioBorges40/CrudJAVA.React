package testes;

import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.google.gson.Gson;

import entity.Notificacao;

public class BuscarNotificacaoTest extends AmbientedeTeste {
	
	@Before
	public void gerarAmbiente() throws Exception {
	}
	@After
	public void limparAmbiente() throws Exception{
	}
	
	@Test
	public void sucessoBuscar() throws Exception{
		// Arrange
		criarNotificacao();
		Gson gson = new Gson();
		Notificacao notificacao = getNotificacao();
				
		// Act
		String request = gson.toJson(notificacao);
				
		String responseJson =
				Request.Post(getUriNot() + "/buscar")
					.bodyString(request, ContentType.APPLICATION_JSON)
					.execute()
					.returnContent().toString();
		
		Notificacao[] responseObject = gson.fromJson(responseJson, Notificacao[].class);
		
		apagarNotificacao(responseObject[0]);
		
		// Assert
		Assert.assertEquals(notificacao.getName(), responseObject[0].getName());
	}
	
	@Test
	public void falhaBuscar() throws Exception{
		// Arrange
		Gson gson = new Gson();
		Notificacao notificacao = new Notificacao("random","Nao existe","N�o existe essa notificacao.");
		
		// Act
		String request = gson.toJson(notificacao);
		
		String response =
				Request.Post(getUriNot() + "/buscar")
					.bodyString(request, ContentType.APPLICATION_JSON)
					.execute()
					.returnContent().toString();
		
		// Assert
		Assert.assertEquals("Nao encontrada nenhuma notificacao.",response);
	}
}
