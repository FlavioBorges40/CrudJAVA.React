package testes;

import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.google.gson.Gson;

import entity.Notificacao;

public class AlterarNotificacaoTest extends AmbientedeTeste{
	
	@Before
	public void gerarAmbiente() throws Exception{
	}
	@After
	public void limparAmbiente() throws Exception{
	}
	
	@Test
	public void sucessoAlterarNotificacao() throws Exception{
		criarNotificacao();
		// Arrange
		Gson gson = new Gson();
		Notificacao notificacao = getNotificacaoAlterada();
						
		// Act
		Notificacao notificacaoAntiga = buscarNotificacao(notificacao);
		notificacao.setId(notificacaoAntiga.getId());
		
		String request = gson.toJson(notificacao);

		String responseJson =
				Request.Post(getUriNot() + "/alterar")
					.bodyString(request, ContentType.APPLICATION_JSON)
					.execute()
					.returnContent().toString();
			
		apagarNotificacao(notificacaoAntiga);
		
		// Assert
		Assert.assertEquals("Alterada com sucesso.", responseJson);
	}
}
