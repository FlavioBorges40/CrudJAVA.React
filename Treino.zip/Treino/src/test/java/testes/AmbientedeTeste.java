package testes;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;

import com.google.gson.Gson;

import entity.Notificacao;
import entity.Permissao;
import entity.Token;
import entity.Usuario;

public class AmbientedeTeste {
	private String uriAuth = "http://localhost:8080/Treino/dog/auth";
	private String uriNot = "http://localhost:8080/Treino/dog/not";
	
	private Usuario usuarioNovo = new Usuario("UsuarioNovo","1234");
	private Usuario usuarioValido = new Usuario("UsuarioValido","1234");
	private Usuario usuarioInvalido = new Usuario("UsuarioInvalido","1234");
	private Token TokenValido = new Token("49e8410b-6aac-47c1-90f5-95e898ad1d4c","UsuarioValido","2030-09-25 15:30:00");
	private Token TokenInvalido = new Token("49e8410b-6aac-47c1-90f5-95e898ad1d5j","UsuarioInvalido","2020-03-07 15:30:00");
	private Permissao PermissaoValida = new Permissao("/teste","UsuarioValido");
	private Notificacao notificacao = new Notificacao("id","Teste","mensagem");
	private Notificacao notificacaoAlterada = new Notificacao("id","Teste","nova mensagem alterada");
	private Notificacao novaNotificacao = new Notificacao("id","Nova","notificacao nova");
	
	public String getUriAuth() {
		return uriAuth;
	}
	public String getUriNot() {
		return uriNot;
	}
	public Permissao getPermissaoValida() {
		return PermissaoValida;
	}
	public Usuario getUsuarioValido() {
		return usuarioValido;
	}
	public Usuario getUsuarioInvalido() {
		return usuarioInvalido;
	}
	public Usuario getUsuarioNovo() {
		return usuarioNovo;
	}
	
	public Token getTokenInvalido() {
		return TokenInvalido;
	}
	
	public Token getTokenValido() {
		return TokenValido;
	}
	
	public Notificacao getNotificacao() {
		return notificacao;
	}
	
	public Notificacao getNovaNotificacao() {
		return novaNotificacao;
	}
	
	public Notificacao getNotificacaoAlterada() {
		return notificacaoAlterada;
	}
	
//	GERAR AMBIENTE
	
	public void criarUsuarioValido() throws Exception {
		Gson gson = new Gson();
		String request = gson.toJson(usuarioValido);
		
		String response = Request.Post(uriAuth + "/cadastrar")
							.bodyString( request, ContentType.APPLICATION_JSON)
							.execute()
							.returnContent().toString();

		System.out.println(response);
	}
	
	public void criarUsuarioInvalido() throws Exception {
		Gson gson = new Gson();
		String request = gson.toJson(usuarioInvalido);
		
		Request.Post(uriAuth + "/cadastrar")
			.bodyString( request, ContentType.APPLICATION_JSON)
			.execute()
			.returnContent().toString();
	}
	
	public void requestAdicionarTokens() throws Exception{
		List<Token> tokens = new ArrayList<>();
		tokens.add(TokenValido);
		tokens.add(TokenInvalido);
		Gson gson = new Gson();
		String request = gson.toJson(tokens);
		System.out.println(request);
		
		Request.Post(uriAuth + "/criartokens")
			.bodyString( request, ContentType.APPLICATION_JSON)
			.execute()
			.returnContent().toString();
	}
	
	public void adicionarPermissaoValida() throws Exception{
		Gson gson = new Gson();
		String request = gson.toJson(PermissaoValida);
		Request.Post(uriAuth + "/adicionarpermissao")
			.bodyString(request, ContentType.APPLICATION_JSON)
			.execute()
			.returnContent().toString();
	}
	
	public Token selecionarTokenUsuarioValido() throws Exception{
		Gson gson = new Gson();
		String request = gson.toJson(usuarioValido);
		return (Token)Request.Post(uriAuth + "/adicionarpermissao")
						.bodyString(request, ContentType.APPLICATION_JSON)
						.execute()
						.returnResponse().getEntity();
	}
	
	public void criarNotificacao() throws Exception{
		Gson gson = new Gson();
		String request = gson.toJson(notificacao);
		Request.Post(uriNot + "/criar")
				.bodyString(request, ContentType.APPLICATION_JSON)
				.execute()
				.returnResponse().getEntity();
	}
	
//	LIMPAR AMBIENTE

	public void apagarUsuarioValido() throws Exception {
		Gson gson = new Gson();
		String request = gson.toJson(usuarioValido);
		
		String response = Request.Post(uriAuth + "/apagarusuario")
							.bodyString( request, ContentType.APPLICATION_JSON)
							.execute()
							.returnContent().toString();
		
		System.out.println(response);
	}
	
	public void apagarUsuarioInvalido() throws Exception {
		Gson gson = new Gson();
		String request = gson.toJson(usuarioInvalido);
		
		Request.Post(uriAuth + "/apagarusuario")
			.bodyString( request, ContentType.APPLICATION_JSON)
			.execute()
			.returnContent().toString();
	}
	public void apagarUsuarioNovo() throws Exception {
		Gson gson = new Gson();
		String request = gson.toJson(usuarioNovo);
		
		Request.Post(uriAuth + "/apagarusuario")
			.bodyString( request, ContentType.APPLICATION_JSON)
			.execute()
			.returnContent().toString();
	}
	
	public void requestApagarTokens() throws Exception{
		List<Token> tokens = new ArrayList<>();
		tokens.add(TokenValido);
		tokens.add(TokenInvalido);
		Gson gson = new Gson();
		String request = gson.toJson(tokens);
		System.out.println(request);
		
		Request.Post(uriAuth + "/deletartokens")
			.bodyString( request, ContentType.APPLICATION_JSON)
			.execute()
			.returnContent().toString();
	}
	
	public void deslogarUsuarioValido() throws Exception{
		Gson gson = new Gson();
		String request = gson.toJson(usuarioValido);
		Request.Post(uriAuth + "/apagartoken")
			.bodyString(request, ContentType.APPLICATION_JSON)
			.execute()
			.returnContent().toString();
	}
	
	public void apagarPermissaoValida() throws Exception{
		Gson gson = new Gson();
		String request = gson.toJson(PermissaoValida);
		Request.Post(uriAuth + "/removerpermissao")
			.bodyString(request, ContentType.APPLICATION_JSON)
			.execute()
			.returnContent().toString();
	}
	
	public void apagarNotificacao(Notificacao jn) throws Exception{
		Gson gson = new Gson();
		String request = gson.toJson(jn);
		Request.Post(uriNot + "/apagar")
			.bodyString(request, ContentType.APPLICATION_JSON)
			.execute()
			.returnContent().toString();
	}
	
	public Notificacao buscarNotificacao(Notificacao jn) throws Exception {
		Gson gson = new Gson();
		String request = gson.toJson(jn);
		
		String responseJson =
				Request.Post(getUriNot() + "/buscar")
					.bodyString(request, ContentType.APPLICATION_JSON)
					.execute()
					.returnContent().toString();
		
		Notificacao[] responseObject = gson.fromJson(responseJson, Notificacao[].class);
		return responseObject[0];
	}
	
	
	public void buscarNotificacaoApagar(Notificacao jn) throws Exception {
		Gson gson = new Gson();
		String request = gson.toJson(jn);
		
		String responseJson =
				Request.Post(getUriNot() + "/buscar")
					.bodyString(request, ContentType.APPLICATION_JSON)
					.execute()
					.returnContent().toString();
		
		Notificacao[] responseObject = gson.fromJson(responseJson, Notificacao[].class);
		
		apagarNotificacao(responseObject[0]);
	}
	
}
