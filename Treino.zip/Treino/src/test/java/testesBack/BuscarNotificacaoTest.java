package testesBack;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.google.gson.Gson;

import entity.Notificacao;

public class BuscarNotificacaoTest extends GsonApplication {
	
	@Before
	public void gerarAmbiente() throws Exception {
		criarNotificacao();
	}
	@After
	public void limparAmbiente() throws Exception{
		apagarNotificacaoNome(getNotificacao());
	}
	
	@Test
	public void sucessoBuscar() throws Exception{
		Gson gson = new Gson();
		Notificacao[] responseObject = gson.fromJson(getGsonNotification("/buscar",getNotificacao()), Notificacao[].class);
		Assert.assertEquals(getNotificacao().getName(), responseObject[0].getName());
	}
	
	@Test
	public void falhaBuscar() throws Exception{
		Assert.assertEquals("Nao encontrada nenhuma notificacao.",getGsonNotification("/buscar",getNovaNotificacao()));
	}
}
