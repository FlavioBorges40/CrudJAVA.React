package testesBack;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import entity.Usuario;

public class EntrarTest extends GsonApplication {
	
	@Before
	public void gerarAmbiente() throws Exception {
		criarUsuarioValido();
	}
	
	@After
	public void limparAmbiente() throws Exception {
		apagarUsuarioValido();
		deslogarUsuarioValido();
	}
	
	@Test
	public void sucessoSenhaValida() {
		Assert.assertEquals("Logado com sucesso.", getGsonAuth("/entrar",getUsuarioValido()));
	}
	
	
	@Test
	public void falhaSenhaInvalida() {
		Usuario user = new Usuario(getUsuarioValido().getUsername(),"aleatoriamente");
		Assert.assertEquals("Senha incorreta.", getGsonAuth("/entrar",user));
	}

	@Test
	public void falhaUsuarioNaoEncontrado() {
		Assert.assertEquals("Usuario nao existe.", getGsonAuth("/entrar",getUsuarioInexistente()));
	}
}
