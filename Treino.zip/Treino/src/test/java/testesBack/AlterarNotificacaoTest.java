package testesBack;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import entity.Notificacao;

public class AlterarNotificacaoTest extends GsonApplication{
	
	@Before
	public void gerarAmbiente() throws Exception{
		criarNotificacao();
	}
	@After
	public void limparAmbiente() throws Exception{
		apagarNotificacaoNome(getNotificacao());
	}
	@Test
	public void sucessoAlterarNotificacao() throws Exception{
		Notificacao notificacao = getNotificacaoAlterada();
		Notificacao notificacaoAntiga = buscarNotificacao(notificacao);
		notificacao.setId(notificacaoAntiga.getId());
		Assert.assertEquals("Alterada com sucesso.", getGsonNotification("/alterar",notificacao));
	}
}
