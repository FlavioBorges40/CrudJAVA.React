package testesBack;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CriarNotificacaoTest extends GsonApplication{
	
	@Before
	public void gerarAmbiente() {
	}
	@After
	public void limparAmbiente() {
		apagarNotificacaoNome(getNovaNotificacao());
	}
	
	@Test
	public void sucessoCriarNotificacao() {
		Assert.assertEquals("Criada com sucesso.", getGsonNotification("/criar", getNovaNotificacao()));
	}
//	@Test
//	public void falhaCampoVazio() {
//		Assert.assertEquals("", getGsonNotification("/criar", getNotificacaoVazia()));
//	}
}
