package testesBack;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CadastrarTest extends GsonApplication {
	
	@Before
	public void gerarAmbiente() throws Exception {
		criarUsuarioValido();
	}
	
	@After
	public void limparAmbiente() throws Exception {
		apagarUsuarioNovo();
		apagarUsuarioValido();
		deslogarUsuarioValido();
	}
	
	@Test
	public void sucessoCadastroUsuario() {
		Assert.assertEquals("Usuario cadastrado com sucesso.", getGsonAuth("/cadastrar",getUsuarioNovo()));
	}
	@Test
	public void falhaUsuarioJaExiste() throws Exception {
		Assert.assertEquals("Nome de usuario ja existe, escolha outro.", getGsonAuth("/cadastrar",getUsuarioValido()));
	}
	
	@Test
	public void falhaSenhaPequena() throws Exception {
		Assert.assertEquals("A senha deve ter mais de 8 caracteres.", getGsonAuth("/cadastrar",getUsuarioInvalidoSenha()));
	}
 }
