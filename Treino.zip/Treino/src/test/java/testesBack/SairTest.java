package testesBack;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class SairTest extends GsonApplication {
	
	@Before
	public void gerarAmbiente() throws Exception{
		requestAdicionarTokens();
	}
	
	@After
	public void limparAmbiente() throws Exception{
		requestApagarTokens();
	}
	
	@Test
	public void sucessoSair() {
		Assert.assertEquals("Deslogado com sucesso.", getGsonAuth("/sair",getTokenValido()));
	}
	
	@Test
	public void falhaSairExpirado() {
		Assert.assertEquals("Usuario ja desconectado.", getGsonAuth("/sair",getTokenInvalido()));
	}
	
	@Test
	public void falhaSairJaDeslogado() {
		Assert.assertEquals("Usuario ja desconectado.", getGsonAuth("/sair",getTokenInexistente()));
	}
	
}
