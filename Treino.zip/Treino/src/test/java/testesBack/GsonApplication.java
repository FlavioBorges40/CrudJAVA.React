package testesBack;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;

import com.google.gson.Gson;

import entity.Notificacao;

public class GsonApplication  extends AmbientedeTeste {
	
	public String getGsonNotification(String uri, Notificacao notificacao) {
		
		Gson gson = new Gson();
		String responseJson = null;
		String request = gson.toJson(notificacao);
		
		try {
			responseJson =
					Request.Post(getUriNot() + uri)
						.bodyString(request, ContentType.APPLICATION_JSON)
						.execute()
						.returnContent().toString();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return responseJson;
	}
	
	public String getGsonAuth(String uri, Object perm) {
		Gson gson = new Gson();
		String responseJson = null;
		String request = gson.toJson(perm);

		try {
			responseJson = Request.Post(getUriAuth() + uri)
								.bodyString(request, ContentType.APPLICATION_JSON)
								.execute()
								.returnContent().toString();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return responseJson;
	}
}
