package testesBack;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import entity.TokenPermissaoTO;

public class AcessoTest extends GsonApplication {

	@Before
	public void gerarAmbiente() throws Exception{
		criarUsuarioValido();
		requestAdicionarTokens();
		adicionarPermissaoValida();
	}
	
	@After
	public void limparAmbiente() throws Exception{
		apagarUsuarioValido();
		requestApagarTokens();
		apagarPermissaoValida();
	}
	
	@Test
	public void sucessoAcessarPaginaRestrita() {
		TokenPermissaoTO perm = new TokenPermissaoTO(getTokenValido().getToken(),getPermissaoValida().getUri());
		Assert.assertEquals("Acesso liberado.", getGsonAuth("/permissao",perm));
	}
	
	@Test
	public void falhaAcessarPaginaRestrita() {
		TokenPermissaoTO perm = new TokenPermissaoTO(getTokenValido().getToken(),"/secreto");
		Assert.assertEquals("Acesso negado.", getGsonAuth("/permissao",perm));
	}
}
