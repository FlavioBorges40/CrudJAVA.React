package poc;

import java.sql.SQLException;
import java.util.List;

import javax.ejb.Stateful;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

@Stateful
public class NotificationService {
	
	@PersistenceContext(name="poc")
	private EntityManager em;
	
	/*
	 * public NotificationService() { EntityManagerFactory emf =
	 * Persistence.createEntityManagerFactory("poc"); em =
	 * emf.createEntityManager(); }
	 */
	
	@Transactional
	public void salvar(Notification e) {
		em.persist(e);
	}
	public void atualizar() {
	}
	
	@Transactional
	public Notification select(String id)  {
		/*
		 * Query grab = em.createQuery("SELECT n FROM Notification n WHERE n.id = 1");
		 */
		return (Notification)em.createQuery("SELECT n FROM Notification n WHERE n.id = :id")
				.setParameter("id", id).getSingleResult();
	}
	
	@SuppressWarnings("unchecked")
	@Transactional
	public List<Notification> listar(){
		return em.createQuery("SELECT n FROM Notification n").getResultList();
	}
	
	@Transactional
	public Notification change(String id, String name, String msg) {
		Notification ent = select(id);
		if(ent != null) {
			ent.setName(name);
			ent.setMsg(msg);
			em.merge(ent);
			return ent;
		}
		else {
			return ent;
		}
	}
	
	@Transactional
	public boolean delete(String id) {
		try {
			Notification ent = select(id);
			em.remove(ent);
			return true;
		}
		catch(Exception e) {
			return false;
		}
	}
	
}
