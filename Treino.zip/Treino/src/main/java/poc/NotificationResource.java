package poc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.UUID;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/not")
public class NotificationResource {
	
	@Inject
	private NotificationService service;
	
	@GET
	@Path("/ping")
	public Response pingNotification() {
		return Response.ok().entity("Servi�o Online").build();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/list")
	public Response getList() {
		return Response.ok().entity(service.listar()).build();
	}

	@GET
	@Path("/create/{name}/{msg}")
	public Response createNotification(@PathParam("name") String name, @PathParam("msg") String msg) {
		Notification notification = new Notification(UUID.randomUUID().toString(),name,msg);
		service.salvar(notification);
		return Response.ok().entity("Criada com sucesso!").build();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/change/{id}/{name}/{msg}")
	public Response changeNotification(@PathParam("id") String id, @PathParam("name") String name, @PathParam("msg") String msg) {
		return Response.ok().entity(service.change(id, name, msg)).build();
	}
	
	@GET
	@Path("/delete/{id}")
	public Response deleteNotification(@PathParam("id") String id) {
		if(service.delete(id)) {
			return Response.ok().entity("Apagado com sucesso!").build();
		}
		else {
			return Response.ok().entity("Nao foi encontrado!").build();
		}
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/search/{id}")
	public Response searchNotification(@PathParam("id") String id) {
		return Response.ok().entity(service.select(id)).build();
	}
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/checkdb")
	public Response checkDB(){
		final String Url = "jdbc:sqlserver://S2EQUD04;databaseName=DBPOC;user=U998;Password=P@ssw0rd";
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			System.out.println("Trying to connect");
			Connection connection = DriverManager.getConnection(Url);
			return Response.ok().entity("Connection Established Successfull and the DATABASE NAME IS:" + connection.getMetaData().getDatabaseProductName()).build();
		}
		
		catch (Exception e) {
			return Response.ok().entity("Unable to make connection with DB").build();
		}
	}
}
