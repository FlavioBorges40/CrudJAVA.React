package persistence;

import javax.ejb.Stateful;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import entity.Permissao;
import entity.Token;
import entity.TokenPermissaoTO;

@Stateful
public class PermissaoEC {
	@PersistenceContext(name="poc")
	private EntityManager em;
	
	@Transactional
	public void salvarPermissao(Permissao p) {
		em.persist(p);
	}
	
	@Transactional
	public boolean apagarPermissao(Permissao p) {
		try {
			Permissao perm = em.merge(p);
			em.remove(perm);
			return true;
		}
		catch(Exception e) {
			System.out.println(e);
			return false;
		}
	}
	
	@Transactional
	public Permissao selecionarPermissao(Permissao p) {
		try {
			Permissao perm = (Permissao)em.createQuery("SELECT p FROM Permissao p WHERE p.username = :username AND p.uri = :uri")
								.setParameter("username", p.getUsername()).setParameter("uri", p.getUri())
								.getSingleResult();
			System.out.println(perm);
			return perm;
		}
		catch(NoResultException e) {
			System.out.println(e);
			return null;
		}
	}
	
	@Transactional
	public Permissao selecionarTokenPermissao(TokenPermissaoTO tpt) {
		try {
			Token tk = (Token) em.createQuery("SELECT t FROM Token t WHERE t.token = :token")
						.setParameter("token", tpt.getToken()).getSingleResult();
			return (Permissao) em.createQuery("SELECT p FROM Permissao p WHERE p.username = :username AND p.uri = :uri")
						.setParameter("username", tk.getUsername()).setParameter("uri", tpt.getUri()).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}
}
