package persistence;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import entity.Token;
import entity.Usuario;

@Stateless
public class TokenEC {
	@PersistenceContext(name="poc")
	private EntityManager em;
	
	@Transactional
	public void salvarToken(Token t) {
		em.persist(t);
	}
	
	@Transactional
	public boolean apagarToken(Token tk) {
		try {
			Token token = em.merge(tk);
			em.remove(token);
			return true;
		}
		catch(Exception e) {
			System.out.println(e);
			return false;
		}
	}
	
	@Transactional
	public Token selecionarToken(Token token) {
		try {
			Token tk = (Token)em.createQuery("SELECT t FROM Token t WHERE t.token = :token")
					.setParameter("token", token.getToken()).getSingleResult();
			System.out.println(tk);
			return tk;
		}
		catch(NoResultException e) {
			System.out.println(e);
			return null;
		}
	}
	
	@Transactional
	public Token selecionarTokenPorNome(String nometoken) {
		try {
			Token tk = (Token)em.createQuery("SELECT t FROM Token t WHERE t.token = :token")
					.setParameter("token", nometoken).getSingleResult();
			System.out.println(tk);
			return tk;
		}
		catch(NoResultException e) {
			return null;
		}
	}

	@Transactional
	public Token selecionarTokenPorUsuario(Usuario usuario) {
		try {
			return (Token)em.createQuery("SELECT t FROM Token t WHERE t.username = :username")
					.setParameter("username", usuario.getUsername()).getSingleResult();
			
		} catch(NoResultException e) {
			return null;
		}
	}
	
	@Transactional
	public Token selecionarTokenPorUsername(String username) {
		try {
			return (Token)em.createQuery("SELECT t FROM Token t WHERE t.username = :username")
					.setParameter("username", username).getSingleResult();
			
		} catch(NoResultException e) {
			return null;
		}
	}
}
