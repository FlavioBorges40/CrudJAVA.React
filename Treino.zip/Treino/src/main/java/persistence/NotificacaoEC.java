package persistence;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import entity.Notificacao;

@Stateless
public class NotificacaoEC {
	
	@PersistenceContext(name="poc")
	private EntityManager em;
	
	@Transactional
	public boolean salvarNotificacao(Notificacao n) {
		try {
			em.persist(n);
		}
		catch(Exception e) {
			return false;
		}
		return true;
	}
	
	@Transactional
	public boolean apagarNotificacao(Notificacao n) {
		try {
			Notificacao not = em.merge(n);
			em.remove(not);
		}
		catch(Exception e) {
			return false;
		}
		return true;
	}
	
	@Transactional
	public void alterarNotificacao(Notificacao n) {
		em.merge(n);
	}
	
	@Transactional
	public Notificacao selecionarNotificacao(Notificacao jn) {
		try {
			return (Notificacao)em.createQuery("SELECT n FROM Notificacao n WHERE n.id = :id")
					.setParameter("id", jn.getId()).getSingleResult(); 
		}
		catch(NoResultException e) {
			return null;
		}
	}
	
	@Transactional
	public Notificacao selecionarNotificacaoPorId(String id) {
		try {
			return (Notificacao)em.createQuery("SELECT n FROM Notificacao n WHERE n.id = :id")
					.setParameter("id", id).getSingleResult();
		}
		catch(NoResultException e) {
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	@Transactional
	public List<Notificacao> listarNotificacoes(){
		return em.createQuery("SELECT n FROM Notificacao n").getResultList();
	}
	
	@SuppressWarnings("unchecked")
	@Transactional
	public List<Notificacao> listarNotificacoesPorNome(String name) {
		try {
			return em.createQuery("SELECT n FROM Notificacao n WHERE n.name = :name")
					.setParameter("name", name).getResultList();
			
//			List<Notificacao> notlist = new ArrayList<Notificacao>(em.createQuery("SELECT n FROM Notificacao n WHERE n.name = :name")
//					.setParameter("name", name).getResultList());
			
		}
		catch(NoResultException e) {
			return null;
		}
	}
	
//	@Transactional
//	public Notification change(String id, String name, String msg) {
//		Notification ent = select(id);
//		if(ent != null) {
//			ent.setName(name);
//			ent.setMsg(msg);
//			em.merge(ent);
//			return ent;
//		}
//		else {
//			return ent;
//		}
//	}
}
