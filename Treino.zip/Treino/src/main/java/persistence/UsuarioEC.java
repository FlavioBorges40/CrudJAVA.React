package persistence;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import entity.Usuario;

@Stateless
public class UsuarioEC {
	
	@PersistenceContext(name="poc")
	private EntityManager em;
	
	@Transactional
	public void salvarUsuario(Usuario u) {
		em.persist(u);
	}
	
	@Transactional
	public void apagarUsuario(Usuario ju) {
		Usuario usuario = em.merge(ju);
		em.remove(usuario);
		
//		em.createQuery("DELETE FROM Usuario u WHERE u.username = :username")
//			.setParameter("username", ju.getUsername())
//			.executeUpdate();
	}
	
	@Transactional
	public Usuario selecionarUsuario(Usuario ju) {
		try {
			return (Usuario) em.createQuery("SELECT u FROM Usuario u WHERE u.username = :username")
					.setParameter("username", ju.getUsername()).getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}
	
	@Transactional
	public Usuario selecionarUsuarioPorSenha(Usuario ju) {
		try {
			return (Usuario) em
					.createQuery("SELECT u FROM Usuario u WHERE u.username = :username AND u.password = :password")
					.setParameter("username", ju.getUsername()).setParameter("password", ju.getPassword())
					.getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}	
}
