package application;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import entity.Permissao;
import entity.Token;
import entity.TokenPermissaoTO;
import entity.Usuario;
import fachada.AutenticaSF;

//LOGICA DE APRESENTA��O
@Path("/auth")
public class AutenticacaoWS {

	@Inject
	private AutenticaSF autenticaSF;
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/cadastrar")
	public Response cadastrarUsuario(Usuario ju) {
		boolean response = autenticaSF.cadastrarUsuario(ju);
		if(response == false) {
			return Response.ok().entity("Nome de usuario ja existe, escolha outro.").build();
		}
		else {
			return Response.ok().entity("Usuario cadastrado com sucesso.").build();
		}
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/entrar")
	public Response entrarUsuario(Usuario ju){
		try {
			autenticaSF.loginUsuario(ju);
		}
		catch(Exception e) {
			return Response.ok().entity(e.getMessage()).build();
		}
		return Response.ok().entity("Logado com sucesso.").build();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/sair")
	public Response sairUsuario(Token jt) {
		try {
			autenticaSF.logoutUsuario(jt);
		}
		catch(Exception e) {
			return Response.ok().entity(e.getMessage()).build();
		}
		return Response.ok().entity("Deslogado com sucesso.").build();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/permissao")
	public Response checarPermissao(TokenPermissaoTO tpt) {
		try {
			autenticaSF.checarPermissao(tpt);
		}
		catch(Exception e) {
			return Response.ok().entity(e.getMessage()).build();
		}
		return Response.ok().entity("Acesso liberado.").build();
	}
	
	
//	SERVI�OS DE TESTE

	@POST
	@Path("/ping")
	public Response pingNotification() {
		return Response.ok().entity("Servi�o Online").build();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/apagarusuario")
	public Response apagarUsuario(Usuario ju) {
		try {
			autenticaSF.apagarUsuario(ju);
		}
		catch(Exception e) {
			return Response.ok().entity(e.getMessage()).build();
		}
		return Response.ok().entity("Apagado com sucesso.").build();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/deletartokens")
	public Response apagarTokensTeste(List<Token> jt) {
		try {
			autenticaSF.apagarTokens(jt);
		}
		catch(Exception e) {
			return Response.ok().entity(e.getMessage()).build();
		}
		return Response.ok().entity("Apagado(s) com sucesso.").build();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/apagartoken")
	public Response apagarTokenTeste(Usuario ju) {
		try {
			autenticaSF.apagarTokenUsuario(ju);
		}
		catch(Exception e) {
			return Response.ok().entity(e.getMessage()).build();
		}
		return Response.ok().entity("Apagado com sucesso.").build();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/criartokens")
	public Response criarTokenTeste(List<Token> jt) {
		autenticaSF.criarTokens(jt);
		return Response.ok().entity("Tokens criados.").build();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/removerpermissao")
	public Response removerPermissao(Permissao jp) {
		try {
			autenticaSF.removerPermissao(jp);
		}
		catch(Exception e) {
			return Response.ok().entity(e.getMessage()).build();
		}
		return Response.ok().entity("Removida com sucesso.").build();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/adicionarpermissao")
	public Response adicionarPermissao(Permissao jp) {
		try {
			autenticaSF.adicionarPermissao(jp);
		}
		catch(Exception e) {
			return Response.ok().entity(e.getMessage()).build();
		}
		return Response.ok().entity("Adicionada com sucesso.").build();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/tokendousuario")
	public Response selecionarTokenUsuario(Usuario ju) {
		return Response.ok().entity(autenticaSF.selecionarTokenUsuario(ju)).build();
	}
	
	
//	
//	@POST
//	@Consumes(MediaType.APPLICATION_JSON)
//	@Produces(MediaType.APPLICATION_JSON)
//	@Path("/select")
//	public Response select(Usuario ju) {
//		return Response.ok().entity(service.selectUsuario(ju)).build();
//	}
	
//	@POST
//	@Produces(MediaType.APPLICATION_JSON)
//	@Path("/token")
//	public Token getToken(Usuario ju) {
//		return service.selectTokenByUsername(ju.getUsername());
//	}
}
