package application;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import entity.Notificacao;
import fachada.NotificacaoSF;

@Path("/not")
public class NotificacaoWS {
	@Inject
	private NotificacaoSF notificacaoSF;
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listar")
	public Response listarNotificacoes() {
		return Response.ok().entity(notificacaoSF.listarNotificacoes()).build();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/criar")
	public Response criarNotificacao(Notificacao jn) {
		try {
			notificacaoSF.criarNotificacao(jn);
		}
		catch(Exception e) {
			return Response.ok().entity(e.getMessage()).build();
		}
		return Response.ok().entity("Criada com sucesso.").build();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/alterar")
	public Response alterarNotificacao(Notificacao jn) {
		try {
			notificacaoSF.alterarNotificacao(jn);
		}
		catch(Exception e) {
			return Response.ok().entity(e.getMessage()).build();
		}
		return Response.ok().entity("Alterada com sucesso.").build();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/apagar")
	public Response apagarNotificacao(Notificacao jn) {
		try {
			notificacaoSF.apagarNotificacao(jn);
		}
		catch(Exception e) {
			return Response.ok().entity(e.getMessage()).build();
		}
		return Response.ok().entity("A notificacao " + jn.getName() + " foi apagada com sucesso.").build();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/buscar")
	public Response buscarNotificacao(Notificacao jn) {
		try {
			return Response.ok().entity(notificacaoSF.buscarNotificacoes(jn)).build();
		}
		catch(Exception e) {
			return Response.ok().entity(e.getMessage()).build();
		}
	}
	
//	SERVI�OS PARA TESTE
	
	@POST
	@Path("/ping")
	public Response pingNotification() {
		return Response.ok().entity("Servi�o Online").build();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/apagarnome")
	public Response apagarNotificacaoNome(Notificacao jn) {
		try {
			notificacaoSF.apagarNotificacaoNome(jn);
		}
		catch(Exception e) {
			return Response.ok().entity(e.getMessage()).build();
		}
		return Response.ok().entity("A notificacao " + jn.getName() + " foi apagada com sucesso.").build();
		
	}
}
