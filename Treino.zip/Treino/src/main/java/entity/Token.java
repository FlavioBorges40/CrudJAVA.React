package entity;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@XmlRootElement
@Table(name="Tokens")
public class Token implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@XmlElement
	private String token;
	@XmlElement
	private String username;
	@XmlElement
	private String expiration;
	
	public Token() {
	}
	
	public Token(String token, String username, String expiration) {
		this.token = token;
		this.username = username;
		this.expiration = expiration;
	}
	
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getExpiration() {
		return expiration;
	}
	public void setExpiration(String expiration) {
		this.expiration = expiration;
	}
	
}