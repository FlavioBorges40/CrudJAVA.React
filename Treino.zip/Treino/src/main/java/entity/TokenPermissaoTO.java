package entity;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class TokenPermissaoTO {
	private String token;
	private String uri;
	
	public TokenPermissaoTO() {
	}
	public TokenPermissaoTO(String token, String uri) {
		this.token = token;
		this.uri = uri;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getUri() {
		return uri;
	}
	public void setUri(String uri) {
		this.uri = uri;
	}
}