package entity;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class TokenResponseTO {
	private String token;
	private String response;
	
	public TokenResponseTO() {
	}
	public TokenResponseTO(String token, String response) {
		this.token = token;
		this.response = response;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
}