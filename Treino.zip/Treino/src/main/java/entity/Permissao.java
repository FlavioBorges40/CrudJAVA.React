package entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@XmlRootElement
@Table(name="Permitions")
public class Permissao implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@XmlElement
	private String uri;
	@XmlElement
	private String username;
	
	public Permissao() {
	}
	
	public Permissao(String uri, String username) {
		this.uri = uri;
		this.username = username;
	}

	public String getUri() {
		return uri;
	}
	public void setUri(String uri) {
		this.uri = uri;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
}
