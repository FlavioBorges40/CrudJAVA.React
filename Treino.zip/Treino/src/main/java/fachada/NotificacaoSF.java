package fachada;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import entity.NaoSalvoException;
import entity.Notificacao;
import exception.AlteracaoException;
import exception.ApagarException;
import exception.ApplicationException;
import exception.NotificacaoNaoEncontradaException;
import service.NotificacaoAS;

@Stateless
public class NotificacaoSF {
	
	@Inject
	private NotificacaoAS notificacaoAS;
	
	public List<Notificacao> listarNotificacoes(){
		return notificacaoAS.listarNotificacoes();
	}
	
	public List<Notificacao> buscarNotificacoes(Notificacao jn) throws ApplicationException {
		ArrayList<Notificacao> notlist = new ArrayList<Notificacao>(notificacaoAS.buscarNotificacoes(jn));
		if(notlist.isEmpty() == true) {
			throw new NotificacaoNaoEncontradaException("Nao encontrada nenhuma notificacao.");
		}
		return notlist;
	}
	
	public void criarNotificacao(Notificacao jn) throws ApplicationException {
		boolean response = notificacaoAS.criarNotificacao(jn);
		if(response == false) {
			throw new NaoSalvoException("Erro ao criar.");
		}
	}
	
	public void alterarNotificacao(Notificacao jn) throws ApplicationException {
		boolean response = notificacaoAS.alterarNotificacao(jn);
		if(response == false) {
			throw new AlteracaoException("Erro ao alterar.");
		}
	}
	
	public void apagarNotificacao(Notificacao jn) throws ApplicationException {
		boolean response = notificacaoAS.apagarNotificacao(jn);
		if(response == false) {
			throw new ApagarException("Erro ao apagar.");
		}
	}
}
