package fachada;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import entity.Permissao;
import entity.Token;
import entity.TokenPermissaoTO;
import entity.Usuario;
import exception.ApplicationException;
import exception.PermissaoJaExisteException;
import exception.PermissaoNaoEncontrada;
import exception.PermissaoNegadaException;
import exception.SenhaIncorretaException;
import exception.TokenNaoEncontradoException;
import exception.UsuarioDesconectadoException;
import exception.UsuarioNaoExisteException;
import service.PermissaoAS;
import service.TokenAS;
import service.UsuarioAS;

@Stateless
public class AutenticaSF {
	
	@Inject
	private UsuarioAS UsuarioAS;
	@Inject
	private TokenAS TokenAS;
	@Inject
	private PermissaoAS permissaoAS;
	
	public boolean cadastrarUsuario(Usuario ju) {
		if(UsuarioAS.verificarExistencia(ju) == false) {
			UsuarioAS.cadastrarUsuario(ju);
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean loginUsuario(Usuario ju) throws ApplicationException {
		boolean response = UsuarioAS.verificarExistencia(ju);
		if(response == false) {
			throw new UsuarioNaoExisteException("Usuario nao existe.");
		}
		response = UsuarioAS.validarSenha(ju);
		if(response == false) {
			throw new SenhaIncorretaException("Senha incorreta.");
		}
		TokenAS.criarToken(ju);
		return true;
	}
	
	public boolean logoutUsuario(Token tk) throws ApplicationException {
		boolean response = TokenAS.tokenLogout(tk);
		if(response == false) {
			throw new UsuarioDesconectadoException("Usuario ja desconectado.");
		}
		return true;
	}
	
	public boolean checarPermissao(TokenPermissaoTO tpt) throws ApplicationException {
		boolean response;
		Token tk = TokenAS.selecionarToken(tpt.getToken());
		response = TokenAS.validarToken(tk);
		if(response == false) {
			return false;
		}
		response = permissaoAS.verificarPermissao(tpt);
		if(response == false) {
			throw new PermissaoNegadaException("Acesso negado.");
		}
		return true;
	}
	
	
//	PARA TESTES
	
	public void adicionarPermissao(Permissao jp) throws ApplicationException {
		boolean response = permissaoAS.criarPermissao(jp);
		if(response == false) {
			throw new PermissaoJaExisteException("Ja existe permissao para esse usuario.");
		}
	}
	
	public void removerPermissao(Permissao jp) throws ApplicationException {
		boolean response = permissaoAS.apagarPermissao(jp);
		if(response == false) {
			throw new PermissaoNaoEncontrada("Permissao nao encontrada.");
		}
	}
	
	public void apagarUsuario(Usuario ju) throws ApplicationException{
		boolean response = UsuarioAS.apagarUsuario(ju);
		if(response == false) {
			throw new UsuarioNaoExisteException("Usuario nao existe.");
		}
	}
	
	public void apagarTokens(List<Token> jt) throws ApplicationException{
		boolean response = TokenAS.apagarTokens(jt);
		if(response == false) {
			throw new TokenNaoEncontradoException("Algum token nao foi encontrado.");
		}
	}
	
	public void criarTokens(List<Token> jt) {
		TokenAS.criarTokens(jt);
	}
	
	public void apagarTokenUsuario(Usuario ju) throws ApplicationException{
		boolean response = TokenAS.apagarTokenUsuario(ju);
		if(response == false) {
			throw new TokenNaoEncontradoException("Token nao foi encontrado.");
		}
	}
	
	public Token selecionarTokenUsuario(Usuario ju) {
		return TokenAS.selecionarTokenUsuario(ju);
	}
}
