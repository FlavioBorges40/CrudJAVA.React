package fachada;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import entity.Permissao;
import entity.Token;
import entity.TokenPermissaoTO;
import entity.Usuario;
import exception.ApplicationException;
import exception.PermissaoJaExisteException;
import exception.PermissaoNaoEncontrada;
import exception.PermissaoNegadaException;
import exception.SenhaIncorretaException;
import exception.SenhaPequenaException;
import exception.TokenNaoEncontradoException;
import exception.UsuarioDesconectadoException;
import exception.UsuarioJaExisteException;
import exception.UsuarioNaoExisteException;
import service.PermissaoAS;
import service.TokenAS;
import service.UsuarioAS;

@Stateless
public class AutenticaSF {
	
	@Inject
	private UsuarioAS UsuarioAS;
	@Inject
	private TokenAS TokenAS;
	@Inject
	private PermissaoAS permissaoAS;
	
	public void cadastrarUsuario(Usuario ju) throws ApplicationException{
		if(UsuarioAS.verificarExistencia(ju) == true) {
			throw new UsuarioJaExisteException("Nome de usuario ja existe, escolha outro.");
		}
		else if(UsuarioAS.verificarSenha(ju) == false) {
			throw new SenhaPequenaException("A senha deve ter mais de 8 caracteres.");
		}
		UsuarioAS.cadastrarUsuario(ju);
	}
	
	public boolean loginUsuario(Usuario ju) throws ApplicationException {
		boolean response = UsuarioAS.verificarExistencia(ju);
		if(response == false) {
			throw new UsuarioNaoExisteException("Usuario nao existe.");
		}
		response = UsuarioAS.validarSenha(ju);
		if(response == false) {
			throw new SenhaIncorretaException("Senha incorreta.");
		}
		TokenAS.criarToken(ju);
		return true;
	}
	
//	public TokenResponseTO loginUsuario(Usuario ju) throws ApplicationException {
//		boolean response = UsuarioAS.verificarExistencia(ju);
//		if(response == false) {
//			throw new UsuarioNaoExisteException("Usuario nao existe.");
//		}
//		response = UsuarioAS.validarSenha(ju);
//		if(response == false) {
//			throw new SenhaIncorretaException("Senha incorreta.");
//		}
//		TokenAS.criarToken(ju);
//		TokenResponseTO trt = new TokenResponseTO(TokenAS.selecionarTokenUsuario(ju).getToken(),"Logado com sucesso.");
//		return trt;
//	}
	
	public boolean logoutUsuario(Token tk) throws ApplicationException {
		boolean response = TokenAS.tokenLogout(tk);
		if(response == false) {
			throw new UsuarioDesconectadoException("Usuario ja desconectado.");
		}
		return true;
	}
	
	public boolean checarPermissao(TokenPermissaoTO tpt) throws ApplicationException {
		boolean response;
		Token tk = TokenAS.selecionarToken(tpt.getToken());
		response = TokenAS.validarToken(tk);
		if(response == false) {
			return false;
		}
		response = permissaoAS.verificarPermissao(tpt);
		if(response == false) {
			throw new PermissaoNegadaException("Acesso negado.");
		}
		return true;
	}
	
	
//	PARA TESTES
	
	public void adicionarPermissao(Permissao jp) throws ApplicationException {
		boolean response = permissaoAS.criarPermissao(jp);
		if(response == false) {
			throw new PermissaoJaExisteException("Ja existe permissao para esse usuario.");
		}
	}
	
	public void removerPermissao(Permissao jp) throws ApplicationException {
		boolean response = permissaoAS.apagarPermissao(jp);
		if(response == false) {
			throw new PermissaoNaoEncontrada("Permissao nao encontrada.");
		}
	}
	
	public void apagarUsuario(Usuario ju) throws ApplicationException{
		boolean response = UsuarioAS.apagarUsuario(ju);
		if(response == false) {
			throw new UsuarioNaoExisteException("Usuario nao existe.");
		}
	}
	
	public void apagarTokens(List<Token> jt) throws ApplicationException{
		boolean response = TokenAS.apagarTokens(jt);
		if(response == false) {
			throw new TokenNaoEncontradoException("Algum token nao foi encontrado.");
		}
	}
	
	public void criarTokens(List<Token> jt) {
		TokenAS.criarTokens(jt);
	}
	
	public void apagarTokenUsuario(Usuario ju) throws ApplicationException{
		boolean response = TokenAS.apagarTokenUsuario(ju);
		if(response == false) {
			throw new TokenNaoEncontradoException("Token nao foi encontrado.");
		}
	}
	
	public Token selecionarTokenUsuario(Usuario ju) {
		return TokenAS.selecionarTokenUsuario(ju);
	}
}
