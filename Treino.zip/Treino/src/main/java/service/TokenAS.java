package service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.ejb.Stateless;
import javax.inject.Inject;

import entity.Token;
import entity.Usuario;
import persistence.TokenEC;

@Stateless
public class TokenAS {
	@Inject
	private TokenEC tokenEC;
	
	public String criarToken(Usuario ju) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MINUTE, 5);
		Token tk = new Token(UUID.randomUUID().toString(), ju.getUsername(), dateFormat.format(cal.getTime()));
		tokenEC.salvarToken(tk);
		return "Sucesso";
	}
	
	public boolean validarToken(Token tk) {
		//retorna false se o usu�rio n�o possui token.
		try {
			if (tokenEC.selecionarToken(tk) == null) {
				return false;
			}
			else {
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date tkold = dateFormat.parse(tk.getExpiration());

				Calendar tkoldc = Calendar.getInstance();
				Calendar agora = Calendar.getInstance();
				tkoldc.setTime(tkold);
				
				//retorna true para token valido.
				if (tkoldc.after(agora)) {
					return true;
				}
				//retorna false e apaga o token se for expirado.
				if (tkoldc.equals(agora)) {
					tokenEC.apagarToken(tk);
					return false;
				}
				//retorna false e apaga o token se for expirado.
				if (tkoldc.before(agora)) {
					tokenEC.apagarToken(tk);
					return false;
				}
			}
		}
		catch(ParseException e){
			return false;
		}
		return false;
	}
	
	public boolean tokenLogin(Usuario ju) {
		//Seleciona o token (se possuir, do contrario � nulo) para gerar/validar.
		Token tk = tokenEC.selecionarTokenPorUsuario(ju);
		boolean response = validarToken(tk);
		
		//Se por algum motivo (verificar acima) o token n�o for v�lido, crie um novo.
		if(response == false) {
			criarToken(ju);
			return true;
		}
		//Token v�lido, apenas prossiga.
		return true;
	}
	
	//recebe os dados ap�s valida��o.
	public boolean tokenLogout(Token tk) {
		boolean response = validarToken(tk);
		//user j� teve o token apagado na valida��o.
		if(response == false) {
			return false;
		}
		//user tem o token apagado para logout.
		tokenEC.apagarToken(tk);
		return true;
	}
	
	public Token selecionarToken(String ntk) {
		return tokenEC.selecionarTokenPorNome(ntk);
	}
	
	public boolean apagarTokens(List<Token> jt) {
		boolean response = true;
		for(int i=0;i<jt.size();i++) {
			if(tokenEC.selecionarToken(jt.get(i)) == null) {
				response = false;
			}
			else {
				tokenEC.apagarToken(jt.get(i));
				response = true;
			}
		}
		return response;
//			return Response.ok().entity("Tokens apagados.").build();
//			return Response.ok().entity("Token " + erro.getToken() + " n�o encontrado.").build();
	}
	
	public boolean criarTokens(List<Token> jt) {
		boolean response = true;
		for(int i=0;i<jt.size();i++) {
			tokenEC.salvarToken(jt.get(i));
			if(tokenEC.selecionarToken(jt.get(i))==jt.get(i)) {
				response = false;
			}
			else {
				tokenEC.salvarToken(jt.get(i));
				response = true;
			}
		}
		return response;
	}
	
	public boolean apagarTokenUsuario(Usuario ju) {
		Token tk = tokenEC.selecionarTokenPorUsuario(ju);
		if(tk == null) {
			return false;
		}
		tokenEC.apagarToken(tk);
		return true;
	}
	
	public Token selecionarTokenUsuario(Usuario ju) {
		return tokenEC.selecionarTokenPorUsuario(ju);
	}
}
