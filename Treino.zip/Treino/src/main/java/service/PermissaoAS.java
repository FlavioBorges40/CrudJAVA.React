package service;

import javax.ejb.Stateless;
import javax.inject.Inject;

import entity.Permissao;
import entity.TokenPermissaoTO;
import persistence.PermissaoEC;

@Stateless
public class PermissaoAS {
	@Inject
	private PermissaoEC permissaoEC;
	
	public boolean verificarPermissao(TokenPermissaoTO tpt) {
		if(permissaoEC.selecionarTokenPermissao(tpt) == null) {
			return false;
		}
		return true;
	}
	
	public boolean criarPermissao(Permissao jp) {
		if(permissaoEC.selecionarPermissao(jp) != null) {
			return false;
		}
		permissaoEC.salvarPermissao(jp);
		return true;
	}
	
	public boolean apagarPermissao(Permissao jp) {
		if(permissaoEC.selecionarPermissao(jp) == null) {
			return false;
		}
		permissaoEC.apagarPermissao(jp);
		return true;
	}
}
