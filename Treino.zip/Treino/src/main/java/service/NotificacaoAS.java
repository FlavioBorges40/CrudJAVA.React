package service;

import java.util.List;
import java.util.UUID;

import javax.ejb.Stateless;
import javax.inject.Inject;

import entity.Notificacao;
import persistence.NotificacaoEC;

@Stateless
public class NotificacaoAS {
	
	@Inject
	private NotificacaoEC notificacaoEC;
	
	public List<Notificacao> listarNotificacoes(){
		return notificacaoEC.listarNotificacoes();
	}
	public List<Notificacao> buscarNotificacoes(Notificacao jn){
		return notificacaoEC.listarNotificacoesPorNome(jn.getName());
	}
	
	public boolean criarNotificacao(Notificacao jn) {
		Notificacao pn = new Notificacao(UUID.randomUUID().toString(), jn.getName(), jn.getMsg());
		return notificacaoEC.salvarNotificacao(pn);
	}
	
	public boolean alterarNotificacao(Notificacao jn) {
		Notificacao anterior = notificacaoEC.selecionarNotificacaoPorId(jn.getId());
		if(anterior == null) {
			return false;
		}
		notificacaoEC.alterarNotificacao(jn);
		return true;
	}
	
	public boolean apagarNotificacao(Notificacao jn) {
		return notificacaoEC.apagarNotificacao(jn);
	}
	
	public boolean apagarNotificacaoNome(Notificacao jn) {
		return notificacaoEC.apagarNotificacaoName(jn);
	}
}
