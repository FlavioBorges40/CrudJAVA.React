package service;

import javax.ejb.Stateless;
import javax.inject.Inject;

import entity.Usuario;
import persistence.UsuarioEC;

@Stateless
public class UsuarioAS {
	
	@Inject
	private UsuarioEC usuarioEC;
	
	public void cadastrarUsuario(Usuario ju) {
		usuarioEC.salvarUsuario(ju);
	}
	
	public boolean validarSenha(Usuario ju) {
		Usuario usuario = usuarioEC.selecionarUsuarioPorSenha(ju);
		if(usuario == null) {
			return false;
		}
		else {
			return true;
		}
	}
	
	public boolean verificarExistencia(Usuario ju) {
		Usuario usuario = usuarioEC.selecionarUsuario(ju);
		if(usuario == null) {
			return false;
		}
		else {
			return true;
		}
	}
	
	public boolean apagarUsuario(Usuario ju) {
		if(verificarExistencia(ju) == true) {
			usuarioEC.apagarUsuario(ju);
			return true;
		}
		return false;
	}
}
