package exception;

public class UsuarioNaoExisteException extends ApplicationException {

	private static final long serialVersionUID = 8550528939508691357L;

	public UsuarioNaoExisteException(String str) {
		super(str);
	}
}
