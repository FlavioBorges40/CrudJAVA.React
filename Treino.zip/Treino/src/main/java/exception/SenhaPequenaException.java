package exception;

public class SenhaPequenaException extends ApplicationException {

	private static final long serialVersionUID = 1L;

	public SenhaPequenaException(String str) {
		super(str);
	}
}
