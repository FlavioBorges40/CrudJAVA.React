package exception;

public class SenhaIncorretaException extends ApplicationException {

	private static final long serialVersionUID = -2187526603255098609L;
	
	public SenhaIncorretaException(String str) {
		super(str);
	}
}
