package exception;

public class AlteracaoException extends ApplicationException {

	private static final long serialVersionUID = 7945883201715115995L;

	public AlteracaoException(String str) {
		super(str);
	}
	
}
