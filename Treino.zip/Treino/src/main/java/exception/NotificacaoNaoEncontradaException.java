package exception;

public class NotificacaoNaoEncontradaException extends ApplicationException {

	private static final long serialVersionUID = 8665000408112683901L;

	public NotificacaoNaoEncontradaException(String str) {
		super(str);
	}

}
