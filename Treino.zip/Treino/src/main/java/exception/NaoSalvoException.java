package exception;

public class NaoSalvoException extends ApplicationException {

	private static final long serialVersionUID = -7592934575988173712L;

	public NaoSalvoException(String str) {
		super(str);
	}

}
