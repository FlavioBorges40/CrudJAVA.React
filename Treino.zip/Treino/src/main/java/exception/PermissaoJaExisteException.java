package exception;

public class PermissaoJaExisteException extends ApplicationException {

	private static final long serialVersionUID = -1469031760590415661L;

	public PermissaoJaExisteException(String str) {
		super(str);
	}

}
