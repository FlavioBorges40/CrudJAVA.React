package exception;

public class UsuarioDesconectadoException extends ApplicationException {

	private static final long serialVersionUID = -8580116379756224608L;

	public UsuarioDesconectadoException(String str) {
		super(str);
	}
	
}
