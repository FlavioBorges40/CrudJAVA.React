package exception;

public class PermissaoNegadaException extends ApplicationException {

	private static final long serialVersionUID = 5153581071811729392L;

	public PermissaoNegadaException(String str) {
		super(str);
	}

}
