package exception;

public class UsuarioInexistenteException extends ApplicationException {

	private static final long serialVersionUID = -9042932703679166035L;

	public UsuarioInexistenteException(String str) {
		super(str);
	}

}
