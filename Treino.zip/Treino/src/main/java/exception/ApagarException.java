package exception;

public class ApagarException extends ApplicationException {

	private static final long serialVersionUID = 3550267862114997043L;

	public ApagarException(String str) {
		super(str);
	}
	
}
