package exception;

public class PermissaoNaoEncontrada extends ApplicationException {

	private static final long serialVersionUID = 5144137810965338215L;

	public PermissaoNaoEncontrada(String str) {
		super(str);
	}
	
}
