package exception;

public class UsuarioJaExisteException extends ApplicationException{
	
	private static final long serialVersionUID = 1L;

	public UsuarioJaExisteException(String str) {
		super(str);
	}
}
