package exception;

public class TokenNaoEncontradoException extends ApplicationException {
	
	private static final long serialVersionUID = 9015604218364852788L;
	
	public TokenNaoEncontradoException(String str) {
		super(str);
	}
	
}
