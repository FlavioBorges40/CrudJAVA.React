package exception;

public class ApplicationException extends Exception{

	private static final long serialVersionUID = -3854679193916312382L;

	public ApplicationException(String str) {
		super(str);
	}
	
}
